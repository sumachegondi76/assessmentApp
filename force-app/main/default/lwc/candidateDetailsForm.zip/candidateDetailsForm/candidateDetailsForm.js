import { LightningElement, wire } from 'lwc';
import getCandidatesWithResults from '@salesforce/apex/candidateDetails.getCandidatesWithResults';

const columns = [
    { label: 'S.No', fieldName: 'rowNumber', type: 'number', cellAttributes: { alignment: 'left' } },
    { label: 'Name', fieldName: 'candidateName' },
    { label: 'Email', fieldName: 'candidateEmail' },
    { label: 'Phone', fieldName: 'candidatePhone' },
    { label: 'Topic', fieldName: 'assessment' },
    { label: 'Assessment Date', type: 'date', fieldName: 'dateField' },
    { label: 'Start Time', type: 'text', fieldName: 'startTime' },
    { label: 'No. of Questions', type: 'number', fieldName: 'numberOfQuestions',cellAttributes: { alignment: 'left' } },
    {label:'Cutoff Marks', fieldName:'cuttoffMarks'},
    { label: 'Marks Obtained', fieldName: 'score', type: 'number', cellAttributes: { alignment: 'left' } },
    {label: 'Result',fieldName:'Result'},
];

export default class candidateDetailsForm extends LightningElement {
    columns = columns;
    data;

    formatTime(timeValue) {
      try {
      if (!timeValue) {
        return ''; // Return empty string for NaN values
      }
  
        const hours = Math.floor(timeValue / 3600000);
        const minutes = Math.floor((timeValue % 3600000) / 60000);
        const seconds = Math.floor((timeValue % 60000) / 1000);
        return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
      } catch (error) {
        console.error('Error formatting time:', error);
        return ''; // Return an empty string in case of any errors
      }
    }

    @wire(getCandidatesWithResults)
    wiredCandidatesWithResults({ error, data }) {
        if (data) {
            this.data = data.map((wrapper, index) => {
                const candidate = wrapper.candidate;
                const result = wrapper.result;

                const cutoffMarks = candidate.Assessment__r ? candidate.Assessment__r.Cutoff_Marks__c : null;
            const Result = result && result.Score__c >= cutoffMarks ? 'Qualified' : 'Not Qualified';
            //const qualificationClass = Result === 'Qualified' ? 'qualification-qualified' : 'qualification-not-qualified';
                return {
                    rowNumber: index + 1,
                    candidateId: candidate.Id,
                    candidateName: candidate.Candidate_Name__c,
                    candidateEmail: candidate.Email__c,
                    candidatePhone: candidate.Phone__c,
                    assessment: candidate.Assessment__r ? candidate.Assessment__r.Name : '',
                    dateField: candidate.Date__c,
                    startTime: this.formatTime(candidate.Start_Time__c),
                    numberOfQuestions: candidate.Assessment__r ? candidate.Assessment__r.No_of_Questions_to_Answer__c : null,
                   
                    cuttoffMarks:candidate.Assessment__r ? candidate.Assessment__r.Cutoff_Marks__c : null,
                    score: result ? result.Score__c : null,
                    Result: Result,
                    //qualificationClass: qualificationClass,
                };
            });
        } else if (error) {
            this.error = error;
            // Handle error if necessary
        }
    }
    
  //   formatTime(timeValue) {
  //     try {
  //         if (!timeValue) {
  //             return ''; // Return empty string for NaN values
  //         }

  //         const date = new Date(`1970-01-01T${timeValue}`);
  //         const formattedTime = date.toLocaleTimeString('en-US', {
  //             hour: 'numeric',
  //             minute: 'numeric',
  //             second: 'numeric',
  //             hour12: true,
  //         });
  //         return formattedTime;
  //     } catch (error) {
  //         console.error('Error formatting time:', error);
  //         return ''; // Return an empty string in case of any errors
  //     }
  // }
}
